package com.javainuse.config;

import java.io.BufferedReader;
import java.io.Serializable;
import java.io.StringReader;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtTokenUtil implements Serializable {

	private static final long serialVersionUID = -2550185165626007488L;
	
	public static final long JWT_TOKEN_VALIDITY = 5*60*60;

	@Value("${jwt.secret}")
	private String secret;

	public String getUsernameFromToken(String token) {
		return getClaimFromToken(token, Claims::getSubject);
	}

	public Date getIssuedAtDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getIssuedAt);
	}

	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getExpiration);
	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}

	private Claims getAllClaimsFromToken(String token) {
		return Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
	}

	private Boolean isTokenExpired(String token) {
		final Date expiration = getExpirationDateFromToken(token);
		return expiration.before(new Date());
	}

	private Boolean ignoreTokenExpiration(String token) {
		// here you specify tokens, for that the expiration is ignored
		return false;
	}

	public String generateToken(UserDetails userDetails) throws Exception {
		Map<String, Object> claims = new HashMap<>();
		claims.put("iss", "3b0b1f82-6ac6-4bc3-8057-450f2f39eb07");
		claims.put("aud", "appstoreconnect-v1");
		claims.put("exp", 1528408800);
		
		return doGenerateToken(claims, userDetails.getUsername());
	}

	private PrivateKey getPrivateKey(String privateKey) throws Exception {
        // Read in the key into a String
        StringBuilder pkcs8Lines = new StringBuilder();
        BufferedReader rdr = new BufferedReader(new StringReader(privateKey));
        String line;
        while ((line = rdr.readLine()) != null) {
            pkcs8Lines.append(line);
        }
        // Remove the "BEGIN" and "END" lines, as well as any whitespace
        String pkcs8Pem = pkcs8Lines.toString();
        pkcs8Pem = pkcs8Pem.replace("-----BEGIN PRIVATE KEY-----", "");
        pkcs8Pem = pkcs8Pem.replace("-----END PRIVATE KEY-----", "");
        pkcs8Pem = pkcs8Pem.replaceAll("\\s+", "");
        // Base64 decode the result
        byte[] pkcs8EncodedBytes = Base64.getDecoder().decode(pkcs8Pem);
        // extract the private key
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(pkcs8EncodedBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privKey = kf.generatePrivate(keySpec);
        return privKey;
    }
	
	private String doGenerateToken(Map<String, Object> claims, String subject) throws Exception {
		
		Map<String, Object> headerClaims = new HashMap();
		headerClaims.put("alg", "ES256");
		headerClaims.put("kid", "X76M3HKD8J");
		headerClaims.put("typ", "JWT");
		//-----------
		
		String privateKey = "-----BEGIN PRIVATE KEY-----\r\n" + 
				"MIGTAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBHkwdwIBAQQgXwf77p7EuuFDl0lQ\r\n" + 
				"OHPiw70RD3Qp+LrWOZBKFx4iTY6gCgYIKoZIzj0DAQehRANCAAT4TzSVTJrecnk0\r\n" + 
				"Y24uzwOWifhasVbLOX5uXhI7jEpg0eTPoU7/GG8JLbyzz/nufsRuFQSnG98t5fZz\r\n" + 
				"5w9UrJiR\r\n" + 
				"-----END PRIVATE KEY-----";
		
		//---------
		
		System.out.println(Jwts.builder().setClaims(claims).setHeader(headerClaims).signWith(SignatureAlgorithm.HS512, secret).compact());
		String token = Jwts.builder().setClaims(claims).setHeader(headerClaims).signWith(SignatureAlgorithm.RS256, getPrivateKey(privateKey)).compact();
		System.out.println("Token :: "+token);
		return Jwts.builder().setClaims(claims).setHeader(headerClaims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY*1000)).signWith(SignatureAlgorithm.HS512, secret).compact();
	}

	public Boolean canTokenBeRefreshed(String token) {
		return (!isTokenExpired(token) || ignoreTokenExpiration(token));
	}

	public Boolean validateToken(String token, UserDetails userDetails) {
		final String username = getUsernameFromToken(token);
		return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}
}
