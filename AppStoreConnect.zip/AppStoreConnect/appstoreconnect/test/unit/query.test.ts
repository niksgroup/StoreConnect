import test from 'ava'

test('nothing', t => t.pass())
